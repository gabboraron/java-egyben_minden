public class KangarooDemo {

    public static void main(String[] args){
        Kangaroo first = Kangaroo("Felix", 100);
        Kangaroo second = Kangaroo(3);
        
        first.display("Ausztralia");
    }
    
}
