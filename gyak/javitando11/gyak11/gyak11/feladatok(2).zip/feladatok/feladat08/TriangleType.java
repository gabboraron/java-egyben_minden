
public enum TriangleType{
  EQUILATERAL, ISOSCELES, SCALENE;
}
